//
//  WeatherDataViewController.swift
//  WeatherApp
//
//  Created by Vijay Godse on 1/26/19.
//  Copyright © 2019 iOS dev 7. All rights reserved.
//

import UIKit

class WeatherDataViewController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    var selectedMetric: AvailableMetric!
    var selectedCountry: AvailableCountry!
    private let cellReuseIdentifier = "WeatherDataTabelViewCell"
    private var weatherDataModel = Array<WeatherDataModel>()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUp()
        
        TMaxDataManager().deleteAll()
    }
    
    private func setUp() {
        self.title = selectedCountry.description + "-" + selectedMetric.description
        configureTableView()
        performGetWeatherData()
    }
    
    private func configureTableView() {
        tableView.delegate = self
        tableView.dataSource = self
        
        //Remove extra seprator lines
        tableView.tableFooterView = UIView()
        
        registerNibs()
    }
    
    private func registerNibs() {
        tableView.register(UINib(nibName: "WeatherDataTabelViewCell", bundle: nil), forCellReuseIdentifier: cellReuseIdentifier)
    }
    
    
    private func performGetWeatherData() {
        
        WeatherDataManager.shared.performGetWeatherData(selectedMetric: selectedMetric, selectedCountry: selectedCountry) { (result) in
            switch result {
            case .success(let response):
                self.saveWeatherDataToDB(weatherData: response)
            case .failure():
                print("Error: Weather data not found")
                //As Weather data not found, fetching from local DB
                self.getDataFromDB()
            }
        }
    }
    
    private func deleteRecordsFromDB() {
        switch self.selectedMetric! {
        case .Tmax:
            TMaxDataManager().deleteAll()
        case .Tmin:
            TMinDataManager().deleteAll()
        case .Rainfall:
            RainfallDataManager().deleteAll()
            
        }
    }
    
    private func saveWeatherDataToDB(weatherData: Array<WeatherDataDTO>) {
        for data in weatherData {
            
            switch self.selectedMetric! {
            case .Tmax:
                TMaxDataManager().saveDataToDB(country: self.selectedCountry.description, data: data)
            case .Tmin:
                TMinDataManager().saveDataToDB(country: self.selectedCountry.description, data: data)
            case .Rainfall:
                RainfallDataManager().saveDataToDB(country: self.selectedCountry.description, data: data)
                
            }
            
            
        }
        getDataFromDB()
    }
    
    private func getDataFromDB() {
        var weatherData: Array<AnyObject>?
        
        switch self.selectedMetric! {
        case .Tmax:
            weatherData = TMaxDataManager().getWeatherDataForCountry(country: self.selectedCountry.description)
        case .Tmin:
            weatherData = TMinDataManager().getWeatherDataForCountry(country: self.selectedCountry.description)
        case .Rainfall:
            weatherData = RainfallDataManager().getWeatherDataForCountry(country: self.selectedCountry.description)
            
        }
        
        if let weatherData = weatherData {
            for data in weatherData {
                var model = WeatherDataModel()
                model.month = Int(data.month)
                model.year = Int(data.year)
                model.value = data.value
                self.weatherDataModel.append(model)
            }
        }
        self.tableView.reloadData()
        
    }
    
    
}

extension WeatherDataViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return weatherDataModel.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: cellReuseIdentifier, for: indexPath) as! WeatherDataTabelViewCell
        cell.yearVal.text = weatherDataModel[indexPath.row].year?.description ?? "N/A"
        cell.monthVal.text = weatherDataModel[indexPath.row].month?.description ?? "N/A"
        cell.reading.text = weatherDataModel[indexPath.row].value?.description ?? "N/A"
        
        return cell
        
    }
    
}

extension WeatherDataViewController: UITableViewDelegate {
    
}


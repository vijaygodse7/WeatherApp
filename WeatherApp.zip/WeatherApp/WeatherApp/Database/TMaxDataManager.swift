//
//  TMaxDataManager.swift
//  WeatherApp
//
//  Copyright © 2019 iOS dev 7. All rights reserved.
//

import Foundation
import CoreData
import UIKit

class TMaxDataManager {
  
    func saveDataToDB(country: String,data: WeatherDataDTO) {

        let appDel = UIApplication.shared.delegate as! AppDelegate
        let managedObjectContext: NSManagedObjectContext = appDel.mainContext
        
        let tMax = NSEntityDescription.insertNewObject(forEntityName: "TMax", into: managedObjectContext) as! TMax
        tMax.country = country
        tMax.month = Int64(data.month!)
        tMax.year = Int64(data.year!)
        tMax.value = Double(data.value!)
        
        
        do {
            // Save Record
            try tMax.managedObjectContext?.save()
            
        } catch {
            let saveError = error as NSError
            print("\(saveError), \(saveError.userInfo)")
        }
        
    }
    
    func getWeatherDataForCountry(country: String) ->[TMax] {
        var tMaxDataList : [TMax] = []
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "TMax")
        let appDel = UIApplication.shared.delegate as! AppDelegate
        let managedObjectContext: NSManagedObjectContext = appDel.mainContext
        
        let predicate = NSPredicate.init(format: "country = %@", country)
        let sortDescriptor = NSSortDescriptor(key: "year", ascending: false)
        let sortDescriptors = [sortDescriptor]
        fetchRequest.sortDescriptors = sortDescriptors
        fetchRequest.predicate = predicate

        do{
            if let tMax = try managedObjectContext.fetch(fetchRequest) as? [TMax]
            {
                if(tMax.count > 0)
                {
                    tMaxDataList = tMax
                }
            }
        }catch{
            print("Error while fetching TMax records")
        }
        return tMaxDataList
        
    }

    func deleteAll() {
        let appDel = UIApplication.shared.delegate as! AppDelegate
        let managedObjectContext: NSManagedObjectContext = appDel.mainContext
        
        let fetch = NSFetchRequest<NSFetchRequestResult>(entityName: "TMax")

        let request = NSBatchDeleteRequest(fetchRequest: fetch)
        do{
            _ = try managedObjectContext.execute(request)
        }catch{
            print("Error while deleting all TMax records")
        }
    }
    
    
}

//
//  RainfallDataManager.swift
//  WeatherApp
//
//  Copyright © 2019 iOS dev 7. All rights reserved.
//

import Foundation
import CoreData
import UIKit

class RainfallDataManager {
    
    func saveDataToDB(country: String,data: WeatherDataDTO) {
        
        let appDel = UIApplication.shared.delegate as! AppDelegate
        let managedObjectContext: NSManagedObjectContext = appDel.mainContext
        
        let rainfall = NSEntityDescription.insertNewObject(forEntityName: "Rainfall", into: managedObjectContext) as! Rainfall
        rainfall.country = country
        rainfall.month = Int64(data.month!)
        rainfall.year = Int64(data.year!)
        rainfall.value = Double(data.value!)
        
        
        do {
            // Save Record
            try rainfall.managedObjectContext?.save()
            
        } catch {
            let saveError = error as NSError
            print("\(saveError), \(saveError.userInfo)")
        }
        
    }
    
    func getWeatherDataForCountry(country: String) ->[Rainfall] {
        var rainfallDataList : [Rainfall] = []
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Rainfall")
        let appDel = UIApplication.shared.delegate as! AppDelegate
        let managedObjectContext: NSManagedObjectContext = appDel.mainContext
        
        let predicate = NSPredicate.init(format: "country = %@", country)
        let sortDescriptor = NSSortDescriptor(key: "year", ascending: false)
        let sortDescriptors = [sortDescriptor]
        fetchRequest.sortDescriptors = sortDescriptors
        fetchRequest.predicate = predicate
        
        do{
            if let rainfall = try managedObjectContext.fetch(fetchRequest) as? [Rainfall]
            {
                if(rainfall.count > 0)
                {
                    rainfallDataList = rainfall
                }
            }
        }catch{
            print("Error while fetching TMax records")
        }
        return rainfallDataList
        
    }
    
    func deleteAll() {
        let appDel = UIApplication.shared.delegate as! AppDelegate
        let managedObjectContext: NSManagedObjectContext = appDel.mainContext
        
        let fetch = NSFetchRequest<NSFetchRequestResult>(entityName: "Rainfall")
        
        let request = NSBatchDeleteRequest(fetchRequest: fetch)
        do{
            _ = try managedObjectContext.execute(request)
        }catch{
            print("Error while deleting all TMin records")
        }
    }
    
    
}

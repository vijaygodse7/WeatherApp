//
//  TMinDataManager.swift
//  WeatherApp
//
//  Copyright © 2019 iOS dev 7. All rights reserved.
//

import Foundation
import CoreData
import UIKit

class TMinDataManager {
    
    func saveDataToDB(country: String,data: WeatherDataDTO) {
        
        let appDel = UIApplication.shared.delegate as! AppDelegate
        let managedObjectContext: NSManagedObjectContext = appDel.mainContext
        
        let tMin = NSEntityDescription.insertNewObject(forEntityName: "TMin", into: managedObjectContext) as! TMin
        tMin.country = country
        tMin.month = Int64(data.month!)
        tMin.year = Int64(data.year!)
        tMin.value = Double(data.value!)
        
        
        do {
            // Save Record
            try tMin.managedObjectContext?.save()
            
        } catch {
            let saveError = error as NSError
            print("\(saveError), \(saveError.userInfo)")
        }
        
    }
    
    func getWeatherDataForCountry(country: String) ->[TMin] {
        var tMinDataList : [TMin] = []
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "TMin")
        let appDel = UIApplication.shared.delegate as! AppDelegate
        let managedObjectContext: NSManagedObjectContext = appDel.mainContext
        
        let predicate = NSPredicate.init(format: "country = %@", country)
        let sortDescriptor = NSSortDescriptor(key: "year", ascending: false)
        let sortDescriptors = [sortDescriptor]
        fetchRequest.sortDescriptors = sortDescriptors
        fetchRequest.predicate = predicate
        
        do{
            if let tMin = try managedObjectContext.fetch(fetchRequest) as? [TMin]
            {
                if(tMin.count > 0)
                {
                    tMinDataList = tMin
                }
            }
        }catch{
            print("Error while fetching TMax records")
        }
        return tMinDataList
        
    }
    
    func deleteAll() {
        let appDel = UIApplication.shared.delegate as! AppDelegate
        let managedObjectContext: NSManagedObjectContext = appDel.mainContext
        
        let fetch = NSFetchRequest<NSFetchRequestResult>(entityName: "TMin")
        
        let request = NSBatchDeleteRequest(fetchRequest: fetch)
        do{
            _ = try managedObjectContext.execute(request)
        }catch{
            print("Error while deleting all TMin records")
        }
    }
    
    
}

//
//  TMax+CoreDataClass.swift
//  
//
//
//

import Foundation
import CoreData

@objc(TMax)
public class TMax: NSManagedObject {

}

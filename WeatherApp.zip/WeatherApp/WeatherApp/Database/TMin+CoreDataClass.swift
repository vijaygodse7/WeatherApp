//
//  TMin+CoreDataClass.swift
//  
//
//
//

import Foundation
import CoreData

@objc(TMin)
public class TMin: NSManagedObject {

}

//
//  Rainfall+CoreDataProperties.swift
//  
//
//
//

import Foundation
import CoreData


extension Rainfall {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Rainfall> {
        return NSFetchRequest<Rainfall>(entityName: "Rainfall")
    }

    @NSManaged public var country: String?
    @NSManaged public var year: Int64
    @NSManaged public var month: Int64
    @NSManaged public var value: Double

}

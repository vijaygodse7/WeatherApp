//
//  Rainfall+CoreDataClass.swift
//  
//
//
//

import Foundation
import CoreData

@objc(Rainfall)
public class Rainfall: NSManagedObject {

}

//
//  TMin+CoreDataProperties.swift
//  
//
//
//

import Foundation
import CoreData


extension TMin {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<TMin> {
        return NSFetchRequest<TMin>(entityName: "TMin")
    }

    @NSManaged public var year: Int64
    @NSManaged public var month: Int64
    @NSManaged public var country: String?
    @NSManaged public var value: Double

}

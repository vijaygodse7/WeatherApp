//
//  TMax+CoreDataProperties.swift
//  
//
//
//

import Foundation
import CoreData


extension TMax {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<TMax> {
        return NSFetchRequest<TMax>(entityName: "TMax")
    }

    @NSManaged public var country: String?
    @NSManaged public var value: Double
    @NSManaged public var month: Int64
    @NSManaged public var year: Int64

}

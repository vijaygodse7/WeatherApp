//
//  WeatherDataTabelViewCell.swift
//  WeatherApp
//
//  Copyright © 2019 iOS dev 7. All rights reserved.
//

import UIKit

class WeatherDataTabelViewCell: UITableViewCell {

    @IBOutlet weak var yearVal: UILabel!
    @IBOutlet weak var monthVal: UILabel!
    @IBOutlet weak var reading: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}

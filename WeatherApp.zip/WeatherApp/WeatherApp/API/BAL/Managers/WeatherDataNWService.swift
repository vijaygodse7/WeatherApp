//
//  WeatherDataNWService.swift
//  WeatherApp
//
//  Copyright © 2019 iOS dev 7. All rights reserved.
//

import Foundation

class WeatherDataNWService {
    func performGetWeatherData(urlString: String, completion:@escaping getWeatherDataCompletionHandler){
        
        let baseAPIHandler = BaseAPIHandler.sharedInstance()
        
        baseAPIHandler.requestForApi(urlString: urlString, method: .get, parameters: nil, headers: nil) { (result) in
            switch result {
            case .success(let data):
                guard let jsonData = data else{
                    completion(.failure())
                    return
                }
                do{
                    let jsonDecoder = JSONDecoder()
                    let data = try jsonDecoder.decode(Array<WeatherDataDTO>.self, from: jsonData)
                    print(data)
                    completion(.success(result:data))
                }
                catch{
                    completion(.failure())
                }
            case .failure:
                completion(.failure())
                
            }
        }
    }
}

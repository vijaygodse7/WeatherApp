//
//  WeatherDataManager.swift
//  WeatherApp
//
//  Copyright © 2019 iOS dev 7. All rights reserved.
//

import Foundation
enum WeatherDataManagerResult<T>{
    case success(result: Array<WeatherDataDTO>)
    case failure()
}

typealias getWeatherDataCompletionHandler = (_ result: WeatherDataManagerResult<WeatherDataDTO>) -> Void

class WeatherDataManager {
    static let shared: WeatherDataManager = WeatherDataManager()
    
    private init() {
    }
    
    func performGetWeatherData(selectedMetric: AvailableMetric, selectedCountry: AvailableCountry, completion:@escaping getWeatherDataCompletionHandler){

        let urlString = Utils.getUrlStringFrom(selectedMetric: selectedMetric, selectedCountry: selectedCountry)
        
        let nwService = WeatherDataNWService()
        nwService.performGetWeatherData(urlString: urlString) { (result) in
            switch result {
            case .success(let response):
                completion(.success(result: response))
            case .failure():
                completion(.failure())
            }
        }
        
    }
    
}


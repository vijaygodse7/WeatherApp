//
//  Utils.swift
//  WeatherApp
//
//  Copyright © 2019 iOS dev 7. All rights reserved.
//

import Foundation

class Utils {
    
    static func getUrlStringFrom(selectedMetric: AvailableMetric, selectedCountry: AvailableCountry)-> String {
        
        var url = "/"
        
        switch selectedMetric {
        case .Tmax:
            url += "Tmax"
        case .Tmin:
            url += "Tmin"
        case .Rainfall:
            url += "Rainfall"
        }
        
        url += "-"
        
        switch selectedCountry {
        case .England:
            url += "England"
        case .UK:
            url += "UK"
        case .Scotland:
            url += "Scotland"
        case .Wales:
            url += "Wales"
        }
        
        url += ".json"
        
        return url
    }
}

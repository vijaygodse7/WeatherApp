//
//  WeatherDataDTO.swift
//  WeatherApp
//
//  Copyright © 2019 iOS dev 7. All rights reserved.
//

import Foundation

struct WeatherDataDTO: Codable {
    var value: Double?
    var year: Int?
    var month: Int?
    
    init(value: Double?, year: Int?, month: Int?) {
        self.value = value
        self.year = year
        self.month = month
    }
}

struct WeatherDataModel {
    var value: Double?
    var year: Int?
    var month: Int?
//    
//    init(value: Double?, year: Int?, month: Int?) {
//        self.value = value
//        self.year = year
//        self.month = month
//    }
}
